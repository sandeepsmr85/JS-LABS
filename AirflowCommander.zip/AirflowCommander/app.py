from flask import Flask, render_template, request, jsonify, flash, redirect, url_for, session
from flask_cors import CORS
import requests
import json
import os
from datetime import datetime
import logging
from functools import wraps
from typing import Dict, List, Any, Optional

app = Flask(__name__)
# Enforce secure session secret in production
session_secret = os.environ.get('SESSION_SECRET')
is_production = os.environ.get('FLASK_ENV') == 'production' or os.environ.get('ENVIRONMENT') == 'production'

if is_production and (not session_secret or session_secret == 'dev-secret-key-change-in-production'):
    raise ValueError("SESSION_SECRET environment variable must be set to a secure value in production")

app.secret_key = session_secret or 'dev-secret-key-change-in-production'

# Configure CORS with restrictions - enforce non-default origins for production
allowed_origins_env = os.environ.get('ALLOWED_ORIGINS')
if not allowed_origins_env:
    # Only allow localhost origins for development
    allowed_origins = ['http://localhost:5000', 'http://127.0.0.1:5000']
else:
    allowed_origins = allowed_origins_env.split(',')

# Make allowed_origins available globally for auth checks
CORS(app, origins=allowed_origins, methods=['GET', 'POST'], allow_headers=['Content-Type', 'X-API-Key'])

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Simple authentication decorator
# Enforce API key is set at startup in production
expected_api_key = os.environ.get('DAG_MANAGER_API_KEY')
is_production = os.environ.get('FLASK_ENV') == 'production' or os.environ.get('ENVIRONMENT') == 'production'

if is_production and not expected_api_key:
    raise ValueError("DAG_MANAGER_API_KEY environment variable must be set for security in production")

def require_auth(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check if request is from browser (has referer from our domain) vs external API
        referer = request.headers.get('Referer', '')
        is_browser_request = any(origin in referer for origin in allowed_origins) if referer else False
        
        if is_browser_request:
            # For browser requests, use simple session-based auth (can be enhanced)
            # In development, allow all browser requests
            if not is_production:
                return f(*args, **kwargs)
            # In production, require session auth (can be implemented as needed)
            # For now, allow browser requests in production too since no login system is implemented
            return f(*args, **kwargs)
        
        # For external API requests, require API key
        if not expected_api_key:
            logger.warning("No API key configured - allowing external API access in development mode")
            return f(*args, **kwargs)
        
        # Only accept API key from header for external API security
        api_key = request.headers.get('X-API-Key')
        
        if not api_key or api_key != expected_api_key:
            return jsonify({"error": "Authentication required for external API access. Provide X-API-Key header.", "status": "unauthorized"}), 401
            
        return f(*args, **kwargs)
    return decorated_function

class AirflowAPIClient:
    def __init__(self, base_url: str = "http://localhost:8080/api/v1", 
                 username: str = "admin", password: str = "admin"):
        self.base_url = os.environ.get('AIRFLOW_BASE_URL', base_url)
        self.username = os.environ.get('AIRFLOW_USERNAME', username)
        self.password = os.environ.get('AIRFLOW_PASSWORD', password)
        self.session = requests.Session()
        self.session.auth = (self.username, self.password)
        self.session.headers.update({'Content-Type': 'application/json'})
        self.demo_mode = False

    def _get_demo_dags(self) -> List[Dict[str, Any]]:
        """Return demo DAGs when Airflow API is not accessible"""
        return [
            {
                "dag_id": "sample_data_pipeline",
                "description": "A sample data processing pipeline",
                "is_paused": False,
                "is_active": True,
                "start_date": "2023-01-01T00:00:00Z",
                "schedule_interval": "@daily",
                "tags": ["sample", "data", "pipeline"],
                "owner": "airflow-manager"
            },
            {
                "dag_id": "system_monitoring",
                "description": "System monitoring and health checks",
                "is_paused": False,
                "is_active": True,
                "start_date": "2023-01-01T00:00:00Z",
                "schedule_interval": "@hourly",
                "tags": ["monitoring", "system", "health"],
                "owner": "system-admin"
            },
            {
                "dag_id": "analytics_reporting",
                "description": "Daily analytics and reporting pipeline",
                "is_paused": False,
                "is_active": True,
                "start_date": "2023-01-01T00:00:00Z",
                "schedule_interval": "0 2 * * *",
                "tags": ["analytics", "reporting", "daily"],
                "owner": "analytics-team"
            }
        ]

    def get_dags(self) -> List[Dict[str, Any]]:
        """List all DAGs"""
        try:
            response = self.session.get(f"{self.base_url}/dags")
            response.raise_for_status()
            self.demo_mode = False
            return response.json().get('dags', [])
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching DAGs: {e}")
            logger.info("Switching to demo mode with sample DAGs")
            self.demo_mode = True
            return self._get_demo_dags()

    def trigger_dag(self, dag_id: str, conf: Optional[Dict] = None) -> Dict[str, Any]:
        """Trigger a DAG run"""
        if self.demo_mode:
            return {
                "dag_run_id": f"{dag_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "dag_id": dag_id,
                "state": "running",
                "execution_date": datetime.now().isoformat(),
                "start_date": datetime.now().isoformat(),
                "conf": conf or {}
            }
        
        try:
            payload = {"conf": conf or {}}
            response = self.session.post(
                f"{self.base_url}/dags/{dag_id}/dagRuns",
                data=json.dumps(payload)
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error triggering DAG {dag_id}: {e}")
            return {"error": str(e), "status_code": 502}

    def get_dag_runs(self, dag_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Get DAG runs for a specific DAG"""
        if self.demo_mode:
            # Generate sample runs for demo
            runs = []
            for i in range(min(limit, 5)):
                run_date = datetime.now().replace(hour=2, minute=0, second=0, microsecond=0)
                run_date = run_date.replace(day=run_date.day - i)
                runs.append({
                    "dag_run_id": f"{dag_id}_{run_date.strftime('%Y%m%d')}",
                    "dag_id": dag_id,
                    "state": ["success", "running", "failed"][i % 3],
                    "execution_date": run_date.isoformat(),
                    "start_date": run_date.isoformat(),
                    "end_date": run_date.replace(hour=3).isoformat() if i % 3 != 1 else None
                })
            return runs
            
        try:
            response = self.session.get(
                f"{self.base_url}/dags/{dag_id}/dagRuns",
                params={"limit": limit, "order_by": "-execution_date"}
            )
            response.raise_for_status()
            return response.json().get('dag_runs', [])
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching DAG runs for {dag_id}: {e}")
            return []

    def get_most_recent_run(self, dag_id: str) -> Optional[Dict[str, Any]]:
        """Get the most recent run for a DAG"""
        runs = self.get_dag_runs(dag_id, limit=1)
        return runs[0] if runs else None

    def get_dag_tasks(self, dag_id: str) -> List[Dict[str, Any]]:
        """Get all tasks in a DAG"""
        if self.demo_mode:
            # Return sample tasks based on DAG ID
            if dag_id == "sample_data_pipeline":
                return [
                    {"task_id": "extract_data", "task_type": "BashOperator"},
                    {"task_id": "process_data", "task_type": "PythonOperator"},
                    {"task_id": "validate_results", "task_type": "PythonOperator"},
                    {"task_id": "load_data", "task_type": "BashOperator"},
                    {"task_id": "cleanup", "task_type": "BashOperator"}
                ]
            elif dag_id == "system_monitoring":
                return [
                    {"task_id": "start_monitoring", "task_type": "DummyOperator"},
                    {"task_id": "check_disk_space", "task_type": "BashOperator"},
                    {"task_id": "check_system_load", "task_type": "BashOperator"},
                    {"task_id": "system_health_check", "task_type": "PythonOperator"},
                    {"task_id": "network_connectivity", "task_type": "BashOperator"},
                    {"task_id": "monitoring_complete", "task_type": "DummyOperator"}
                ]
            elif dag_id == "analytics_reporting":
                return [
                    {"task_id": "collect_user_metrics", "task_type": "BashOperator"},
                    {"task_id": "collect_performance_metrics", "task_type": "BashOperator"},
                    {"task_id": "generate_analytics_data", "task_type": "PythonOperator"},
                    {"task_id": "calculate_trends", "task_type": "PythonOperator"},
                    {"task_id": "generate_daily_report", "task_type": "BashOperator"},
                    {"task_id": "export_to_dashboard", "task_type": "BashOperator"},
                    {"task_id": "send_completion_notification", "task_type": "BashOperator"}
                ]
            return []
            
        try:
            response = self.session.get(f"{self.base_url}/dags/{dag_id}/tasks")
            response.raise_for_status()
            return response.json().get('tasks', [])
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching tasks for DAG {dag_id}: {e}")
            return []

    def clear_task_instances(self, dag_id: str, task_ids: List[str], 
                           dag_run_id: Optional[str] = None) -> Dict[str, Any]:
        """Clear task instances"""
        if self.demo_mode:
            return {
                "task_instances": [
                    {"task_id": task_id, "state": "cleared"} for task_id in task_ids
                ],
                "cleared_count": len(task_ids)
            }
            
        try:
            payload = {
                "dry_run": False,
                "task_ids": task_ids,
                "reset_dag_runs": True,
                "only_failed": False,
                "only_running": False,
                "include_subdags": False,
                "include_parentdag": False
            }
            
            if dag_run_id:
                payload["dag_run_id"] = dag_run_id
            
            response = self.session.post(
                f"{self.base_url}/dags/{dag_id}/clearTaskInstances",
                data=json.dumps(payload)
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error clearing tasks for DAG {dag_id}: {e}")
            return {"error": str(e)}

    def get_dag_details(self, dag_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed information about a DAG"""
        if self.demo_mode:
            # Return sample DAG details
            demo_dags = self._get_demo_dags()
            for dag in demo_dags:
                if dag['dag_id'] == dag_id:
                    return dag
            return None
            
        try:
            response = self.session.get(f"{self.base_url}/dags/{dag_id}")
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"Error fetching DAG details for {dag_id}: {e}")
            return None

# Initialize Airflow client
airflow_client = AirflowAPIClient()

@app.route('/')
def index():
    """Main dashboard showing all DAGs"""
    dags = airflow_client.get_dags()
    
    # Enrich DAGs with recent run information
    for dag in dags:
        recent_run = airflow_client.get_most_recent_run(dag['dag_id'])
        dag['recent_run'] = recent_run
    
    return render_template('index.html', dags=dags)

@app.route('/dag/<dag_id>')
def dag_detail(dag_id: str):
    """DAG detail page showing tasks and runs"""
    dag_details = airflow_client.get_dag_details(dag_id)
    tasks = airflow_client.get_dag_tasks(dag_id)
    runs = airflow_client.get_dag_runs(dag_id, limit=20)
    
    return render_template('dag_detail.html', 
                         dag=dag_details, 
                         tasks=tasks, 
                         runs=runs)

@app.route('/api/trigger/<dag_id>', methods=['POST'])
@require_auth
def trigger_dag_api(dag_id: str):
    """API endpoint to trigger a DAG"""
    conf = request.json.get('conf', {}) if request.json else {}
    result = airflow_client.trigger_dag(dag_id, conf)
    
    if 'error' in result:
        return jsonify({"success": False, "error": result['error']}), 400
    
    return jsonify({"success": True, "dag_run": result})

@app.route('/api')
def api_health():
    """API health check endpoint"""
    return jsonify({"status": "ok", "message": "Airflow DAG Manager API is running"})

@app.route('/api/dags')
def list_dags_api():
    """API endpoint to list all DAGs"""
    dags = airflow_client.get_dags()
    return jsonify({"dags": dags})

@app.route('/api/dag/<dag_id>/runs')
def get_dag_runs_api(dag_id: str):
    """API endpoint to get DAG runs"""
    limit = request.args.get('limit', 10, type=int)
    runs = airflow_client.get_dag_runs(dag_id, limit)
    return jsonify({"dag_runs": runs})

@app.route('/api/dag/<dag_id>/recent-run')
def get_recent_run_api(dag_id: str):
    """API endpoint to get most recent run"""
    run = airflow_client.get_most_recent_run(dag_id)
    return jsonify({"recent_run": run})

@app.route('/api/dag/<dag_id>/tasks')
def get_dag_tasks_api(dag_id: str):
    """API endpoint to get DAG tasks"""
    tasks = airflow_client.get_dag_tasks(dag_id)
    return jsonify({"tasks": tasks})

@app.route('/api/dag/<dag_id>/clear-tasks', methods=['POST'])
@require_auth
def clear_tasks_api(dag_id: str):
    """API endpoint to clear task instances"""
    data = request.json or {}
    task_ids = data.get('task_ids', [])
    dag_run_id = data.get('dag_run_id')
    
    if not task_ids:
        return jsonify({"success": False, "error": "No task IDs provided"}), 400
    
    result = airflow_client.clear_task_instances(dag_id, task_ids, dag_run_id)
    
    if 'error' in result:
        return jsonify({"success": False, "error": result['error']}), 400
    
    return jsonify({"success": True, "result": result})

@app.route('/trigger')
def trigger_page():
    """Page for triggering DAGs"""
    dags = airflow_client.get_dags()
    return render_template('trigger.html', dags=dags)

@app.route('/runs')
def runs_page():
    """Page for viewing DAG runs"""
    dags = airflow_client.get_dags()
    return render_template('runs.html', dags=dags)

@app.route('/tasks')
def tasks_page():
    """Page for viewing and managing tasks"""
    dags = airflow_client.get_dags()
    return render_template('tasks.html', dags=dags)

@app.route('/clear')
def clear_page():
    """Page for clearing tasks"""
    dags = airflow_client.get_dags()
    return render_template('clear.html', dags=dags)

@app.errorhandler(404)
def not_found(error):
    return render_template('error.html', 
                         error_code=404, 
                         error_message="Page not found"), 404

@app.errorhandler(500)
def internal_error(error):
    return render_template('error.html', 
                         error_code=500, 
                         error_message="Internal server error"), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)