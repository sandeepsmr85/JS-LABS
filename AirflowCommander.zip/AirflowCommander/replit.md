# Overview

This is an Airflow DAG Manager web application built with Flask that provides a user-friendly interface for managing Apache Airflow DAGs (Directed Acyclic Graphs). The application serves as a centralized dashboard for monitoring, triggering, and managing DAG runs and tasks in an Airflow environment. It includes features for viewing DAG statuses, triggering manual runs, monitoring task executions, and clearing failed tasks.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Template Engine**: Jinja2 templating with Flask for server-side rendering
- **UI Framework**: Bootstrap 5 for responsive design and component styling
- **Icons**: Font Awesome for consistent iconography
- **JavaScript**: Vanilla JavaScript for client-side interactions and AJAX requests
- **Navigation**: Multi-page application with consistent navigation bar and breadcrumbs

## Backend Architecture
- **Web Framework**: Flask as the primary web application framework
- **API Integration**: RESTful communication with Apache Airflow's REST API
- **Session Management**: Flask sessions with configurable secret keys for security
- **Authentication**: Custom decorator-based authentication system supporting both browser and API access
- **Error Handling**: Centralized error handling with custom error pages
- **Logging**: Python logging module for application monitoring

## Security Model
- **Environment-based Configuration**: Separate settings for development and production environments
- **API Key Authentication**: Required API key for external access in production
- **CORS Protection**: Configurable allowed origins with strict production requirements
- **Session Security**: Enforced secure session secrets in production environments

## Application Structure
- **Route Organization**: RESTful endpoints for different DAG management functions
- **Template Inheritance**: Base template with consistent layout across all pages
- **Static Asset Management**: Organized CSS and JavaScript files for maintainability
- **Responsive Design**: Mobile-friendly interface with Bootstrap grid system

## Data Flow
- **API Proxy Pattern**: Application acts as a proxy between users and Airflow API
- **Real-time Updates**: AJAX-based data fetching for dynamic content updates
- **State Management**: Client-side state management for form interactions and data display

# External Dependencies

## Core Dependencies
- **Flask**: Web application framework and routing
- **Flask-CORS**: Cross-origin resource sharing configuration
- **Bootstrap 5**: Frontend UI framework via CDN
- **Font Awesome**: Icon library via CDN

## External Services
- **Apache Airflow**: Primary integration for DAG management via REST API
- **Airflow REST API**: All DAG operations including listing, triggering, monitoring, and task management

## Runtime Requirements
- **Python Environment**: Flask application server
- **Environment Variables**: Configuration through environment variables for security
- **Session Storage**: Server-side session management for user state

## Optional Integrations
- **Auto-refresh**: Client-side periodic data refresh functionality
- **AJAX Endpoints**: Asynchronous data loading for improved user experience