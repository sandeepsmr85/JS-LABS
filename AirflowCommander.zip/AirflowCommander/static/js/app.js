// Airflow DAG Manager JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Auto-refresh functionality
    const autoRefreshCheckbox = document.getElementById('auto-refresh');
    let refreshInterval;
    
    if (autoRefreshCheckbox) {
        autoRefreshCheckbox.addEventListener('change', function() {
            if (this.checked) {
                refreshInterval = setInterval(() => {
                    location.reload();
                }, 30000); // Refresh every 30 seconds
            } else {
                clearInterval(refreshInterval);
            }
        });
    }
    
    // Common AJAX error handler
    window.handleAjaxError = function(error) {
        console.error('AJAX Error:', error);
        alert('An error occurred. Please check the console for details.');
    };
    
    // Add loading state to buttons
    window.addLoadingState = function(button, loadingText = 'Loading...') {
        const originalText = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ' + loadingText;
        
        return function() {
            button.disabled = false;
            button.innerHTML = originalText;
        };
    };
    
    // Format dates consistently
    window.formatDate = function(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleString();
    };
    
    // Status badge helper
    window.getStatusBadge = function(state) {
        const badges = {
            'success': 'bg-success',
            'failed': 'bg-danger',
            'running': 'bg-primary',
            'queued': 'bg-warning',
            'up_for_retry': 'bg-info',
            'up_for_reschedule': 'bg-info',
            'upstream_failed': 'bg-secondary',
            'skipped': 'bg-secondary',
            'scheduled': 'bg-info'
        };
        
        const badgeClass = badges[state] || 'bg-secondary';
        return `<span class="badge ${badgeClass}">${state}</span>`;
    };
    
    // Common fetch wrapper with error handling
    window.apiCall = function(url, options = {}) {
        return fetch(url, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .catch(error => {
            console.error('API call failed:', error);
            throw error;
        });
    };
    
    // Initialize any existing trigger buttons
    const triggerButtons = document.querySelectorAll('.trigger-dag-btn');
    triggerButtons.forEach(button => {
        button.addEventListener('click', function() {
            const dagId = this.dataset.dagId;
            if (dagId) {
                console.log('Triggering DAG:', dagId);
            }
        });
    });
    
    // Add confirmation to destructive actions
    const destructiveButtons = document.querySelectorAll('.btn-danger, .clear-run-btn');
    destructiveButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to perform this action?')) {
                e.preventDefault();
                return false;
            }
        });
    });
});

// Global utility functions
window.showAlert = function(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
};

window.copyToClipboard = function(text) {
    navigator.clipboard.writeText(text).then(() => {
        showAlert('Copied to clipboard!', 'success');
    }).catch(() => {
        showAlert('Failed to copy to clipboard', 'error');
    });
};