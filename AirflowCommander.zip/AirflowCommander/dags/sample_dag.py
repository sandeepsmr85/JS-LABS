from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

# Default arguments for all tasks
default_args = {
    'owner': 'airflow-manager',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1)
}

# Define the DAG
dag = DAG(
    'sample_data_pipeline',
    default_args=default_args,
    description='A sample data processing pipeline',
    schedule_interval='@daily',
    catchup=False,
    tags=['sample', 'data', 'pipeline']
)

def process_data():
    """Sample Python function for data processing"""
    print("Processing data...")
    import time
    time.sleep(2)  # Simulate processing
    print("Data processing completed!")
    return "success"

def validate_results():
    """Sample validation function"""
    print("Validating results...")
    import time
    time.sleep(1)
    print("Validation completed!")
    return "validated"

# Task 1: Extract data
extract_data = BashOperator(
    task_id='extract_data',
    bash_command='echo "Extracting data from source..."',
    dag=dag
)

# Task 2: Process data using Python
process_data_task = PythonOperator(
    task_id='process_data',
    python_callable=process_data,
    dag=dag
)

# Task 3: Validate results
validate_task = PythonOperator(
    task_id='validate_results',
    python_callable=validate_results,
    dag=dag
)

# Task 4: Load data
load_data = BashOperator(
    task_id='load_data',
    bash_command='echo "Loading processed data to destination..."',
    dag=dag
)

# Task 5: Cleanup
cleanup = BashOperator(
    task_id='cleanup',
    bash_command='echo "Cleaning up temporary files..."',
    dag=dag
)

# Define task dependencies
extract_data >> process_data_task >> validate_task >> load_data >> cleanup