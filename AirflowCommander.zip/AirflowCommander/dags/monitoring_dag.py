from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
try:
    from airflow.operators.dummy import DummyOperator
except ImportError:
    from airflow.operators.dummy_operator import DummyOperator

default_args = {
    'owner': 'system-admin',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 2,
    'retry_delay': timedelta(minutes=5)
}

dag = DAG(
    'system_monitoring',
    default_args=default_args,
    description='System monitoring and health checks',
    schedule_interval='@hourly',
    catchup=False,
    tags=['monitoring', 'system', 'health']
)

def check_system_health():
    """Check system health metrics"""
    import psutil
    import json
    
    # Get system metrics
    cpu_percent = psutil.cpu_percent(interval=1)
    memory_info = psutil.virtual_memory()
    disk_info = psutil.disk_usage('/')
    
    metrics = {
        'cpu_percent': cpu_percent,
        'memory_percent': memory_info.percent,
        'disk_percent': disk_info.percent,
        'timestamp': datetime.now().isoformat()
    }
    
    print(f"System Health Metrics: {json.dumps(metrics, indent=2)}")
    
    # Alert if any metric is above threshold
    if cpu_percent > 80:
        print("WARNING: CPU usage is high!")
    if memory_info.percent > 80:
        print("WARNING: Memory usage is high!")
    if disk_info.percent > 80:
        print("WARNING: Disk usage is high!")
    
    return metrics

# Start task
start = DummyOperator(
    task_id='start_monitoring',
    dag=dag
)

# Check disk space
check_disk = BashOperator(
    task_id='check_disk_space',
    bash_command='df -h | head -10',
    dag=dag
)

# Check system load
check_load = BashOperator(
    task_id='check_system_load',
    bash_command='uptime && top -bn1 | head -20',
    dag=dag
)

# Python health check
health_check = PythonOperator(
    task_id='system_health_check',
    python_callable=check_system_health,
    dag=dag
)

# Check network connectivity
network_check = BashOperator(
    task_id='network_connectivity',
    bash_command='ping -c 3 8.8.8.8 || echo "Network check failed"',
    dag=dag
)

# End task
end = DummyOperator(
    task_id='monitoring_complete',
    dag=dag
)

# Task dependencies
start >> [check_disk, check_load] >> health_check >> network_check >> end