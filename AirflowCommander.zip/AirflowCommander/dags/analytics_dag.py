from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator

default_args = {
    'owner': 'analytics-team',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=2)
}

dag = DAG(
    'analytics_reporting',
    default_args=default_args,
    description='Daily analytics and reporting pipeline',
    schedule_interval='0 2 * * *',  # Run daily at 2 AM
    catchup=False,
    tags=['analytics', 'reporting', 'daily']
)

def generate_sample_data():
    """Generate sample analytics data"""
    import random
    import json
    from datetime import datetime, timedelta
    
    # Generate sample metrics for the last 24 hours
    end_time = datetime.now()
    start_time = end_time - timedelta(hours=24)
    
    analytics_data = {
        'report_date': end_time.strftime('%Y-%m-%d'),
        'metrics': {
            'total_users': random.randint(1000, 5000),
            'active_sessions': random.randint(100, 800),
            'page_views': random.randint(5000, 25000),
            'conversion_rate': round(random.uniform(2.0, 8.0), 2),
            'avg_session_duration': round(random.uniform(120, 600), 1)
        },
        'top_pages': [
            {'page': '/dashboard', 'views': random.randint(500, 2000)},
            {'page': '/analytics', 'views': random.randint(300, 1500)},
            {'page': '/reports', 'views': random.randint(200, 1000)},
            {'page': '/settings', 'views': random.randint(100, 800)}
        ]
    }
    
    print(f"Generated Analytics Data: {json.dumps(analytics_data, indent=2)}")
    return analytics_data

def calculate_trends():
    """Calculate analytics trends"""
    import random
    
    # Simulate trend calculations
    trends = {
        'user_growth': f"{random.uniform(-5.0, 15.0):.1f}%",
        'engagement_change': f"{random.uniform(-10.0, 20.0):.1f}%",
        'performance_score': random.randint(75, 95)
    }
    
    print(f"Calculated Trends: {trends}")
    return trends

# Data collection tasks
collect_user_data = BashOperator(
    task_id='collect_user_metrics',
    bash_command='echo "Collecting user engagement metrics..."',
    dag=dag
)

collect_performance_data = BashOperator(
    task_id='collect_performance_metrics',
    bash_command='echo "Collecting system performance metrics..."',
    dag=dag
)

# Data processing
generate_data = PythonOperator(
    task_id='generate_analytics_data',
    python_callable=generate_sample_data,
    dag=dag
)

calculate_trends_task = PythonOperator(
    task_id='calculate_trends',
    python_callable=calculate_trends,
    dag=dag
)

# Report generation
generate_daily_report = BashOperator(
    task_id='generate_daily_report',
    bash_command='echo "Generating daily analytics report..."',
    dag=dag
)

# Data export
export_to_dashboard = BashOperator(
    task_id='export_to_dashboard',
    bash_command='echo "Exporting data to analytics dashboard..."',
    dag=dag
)

# Notification
send_notification = BashOperator(
    task_id='send_completion_notification',
    bash_command='echo "Analytics pipeline completed successfully!"',
    dag=dag
)

# Task dependencies
[collect_user_data, collect_performance_data] >> generate_data >> calculate_trends_task >> generate_daily_report >> export_to_dashboard >> send_notification