from flask import Flask, request, jsonify, send_file
import json

app = Flask(__name__)

@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    # Dummy ticket info
    ticket_info = {
        "id": data.get("ticket_id", "PROJ-123"),
        "title": "Sample Jira Ticket",
        "status": "In Progress",
        "priority": "High",
        "issue_type": "Story",
        "description": "This is a sample Jira ticket description.",
        "epic": {
            "title": "Epic Example",
            "description": "Epic description here",
            "user_stories": [{"title": "User Story 1"}, {"title": "User Story 2"}]
        }
    }

    # Dummy test cases
    test_cases = [
        {
            "id": "TC-001",
            "title": "Verify login functionality",
            "description": "Ensure user can log in with valid credentials.",
            "priority": "High",
            "type": "Functional",
            "preconditions": "User is registered and active.",
            "steps": [
                "Navigate to login page",
                "Enter valid username and password",
                "Click login button"
            ],
            "expected_result": "User should be redirected to the dashboard."
        },
        {
            "id": "TC-002",
            "title": "Verify error message on invalid login",
            "description": "Ensure error message appears with invalid credentials.",
            "priority": "Medium",
            "type": "Negative",
            "preconditions": "User exists in the system.",
            "steps": [
                "Navigate to login page",
                "Enter invalid username or password",
                "Click login button"
            ],
            "expected_result": "User should see an error message."
        }
    ]

    return jsonify({"ticket_info": ticket_info, "test_cases": test_cases})

@app.route('/export/<format>')
def export(format):
    data = request.args.get("data")
    if not data:
        return jsonify({"error": "No data provided"}), 400

    test_cases = json.loads(data)

    if format == "csv":
        csv_content = "ID,Title,Description,Priority,Type,Preconditions,Steps,Expected Result\n"
        for tc in test_cases:
            steps = " | ".join(tc["steps"])
            csv_content += f"{tc['id']},{tc['title']},{tc['description']},{tc['priority']},{tc['type']},{tc.get('preconditions','')},{steps},{tc['expected_result']}\n"

        file_path = "test_cases.csv"
        with open(file_path, "w") as f:
            f.write(csv_content)
        return send_file(file_path, as_attachment=True)

    elif format == "json":
        file_path = "test_cases.json"
        with open(file_path, "w") as f:
            json.dump(test_cases, f, indent=2)
        return send_file(file_path, as_attachment=True)

    return jsonify({"error": "Invalid export format"}), 400

if __name__ == '__main__':
    app.run(debug=True)
